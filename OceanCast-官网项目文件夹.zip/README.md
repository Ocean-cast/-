# OceanCast 公司官网项目

这个文件夹包含可编辑的 Next.js 官网源码、网站素材，以及可以直接打开的静态预览。

## 直接预览

双击 OceanCast-网页预览.html 可查看页面样式、作品展示、客服二维码和人工客服入口。该文件是离线预览，不连接 YNS 后台、真实 AI 对话或订单系统。

## 运行完整源码

需要 Node.js 24+ 和 pnpm。在此文件夹打开 PowerShell：

    pnpm install --frozen-lockfile
    Copy-Item .env.example .env.local

在 .env.local 中配置你自己的 YNS_API_KEY，然后运行：

    pnpm exec next dev

浏览器打开 http://localhost:3000。

## 后台与安全

正式网站需要有效的 YourNextStore API key；AI 对话还需在 YNS 后台启用 StoreChat。密钥只写在本机 .env.local 或托管平台的私有环境变量中，不要发到聊天里，也不要提交到 GitHub。这个文件夹没有包含真实密钥。

最新企业微信二维码已放在 public/contact/wecom-contact.jpg。素材也保存在 public/ 目录。

GitHub 源码仓库：https://github.com/egizipinto345-rgb/- 。此文件夹是独立副本，本地修改不会自动同步到 GitHub。

原模板使用 MIT 许可，详见 LICENSE.md。